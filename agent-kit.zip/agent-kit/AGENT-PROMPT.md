# Prompt: add PyPath to the Medical Analytics Training website

Copy everything below the line into a new Claude Code session opened in the website
project. First replace the two paths in the "Inputs" section.

---

You are adding **PyPath**, a 30-day beginner Python course, to my partner's website
**Medical Analytics Training** (repo `Group_Master_Ai`). Work carefully and match the
existing project exactly.

## Inputs

- Website project: `<PROJECT_PATH>` (the `Group_Master_Ai` folder; the site itself is in
  `medical-analytics-training/`)
- PyPath course folder: `<PYPATH_PATH>` (contains `PROCESS.md`, `day01/`, `day02/`,
  `tools/`, `agent-kit/`)
- PyPath knowledge file: `<PYPATH_PATH>/agent-kit/PYPATH-KNOWLEDGE.md`
- PyPath skill: `<PYPATH_PATH>/agent-kit/skills/pypath-course/SKILL.md`

## Step 1: read before you change anything (required)

Don't edit a single file until you've done all of this, and tell me in a short summary
what you learned.

1. Read `PYPATH-KNOWLEDGE.md` fully, then the skill's `SKILL.md`, and follow both. If the
   skill isn't installed, copy the folder `agent-kit/skills/pypath-course/` to
   `<PROJECT_PATH>/.claude/skills/pypath-course/` so it's available, or just follow it
   as a document.
2. Read the **`.claude` folder** of the website project (`<PROJECT_PATH>/.claude/`, e.g.
   `launch.json`) to understand how my partner works: how the site is served (a Python
   `http.server` on port 8765 serving `medical-analytics-training/`) and any other
   settings, skills or notes in there. Follow the same way of working.
3. Read the website project folder: `README.md`, then in `medical-analytics-training/`:
   `index.html`, `lecture-1.html`, `lecture-2.html`, `agent-report.html`, **all of**
   `js/shared.js` (especially sections 1 BRAND, 3 language/theme, the `I18N`
   dictionaries for `en` and `ar`, and section 12 "Page shell": `Shell.links()`,
   `langSwitch()`, `themeBtn()`, `renderHeader()`, `renderDrawer()`, `init()`),
   `js/home.js`, `js/lecture.js`, `js/report.js`, **all of** `css/shared.css` (header,
   `.main-nav`, `.header-tools`, `.drawer`, `.drawer-tools`, and the `@media` breakpoints
   at 1100 px, 980 px and 680 px), and `tools/make_share_package.py`. Also check
   `git status` and `git log` so you don't disturb uncommitted work.
4. Read the PyPath folder: `PROCESS.md`, `day01/index.html`, `day01/style.css`,
   `day01/script.js`, `day02/index.html`. Some PyPath day folders also contain the author's
   unrelated personal files (`.venv`, `.py` scripts, big CSVs, even a copy of this
   website). They are **not** part of the course. Never copy them.

Make every change the same way the website already works: its file layout, naming, i18n
keys (`t("nav.…")`, `L(en, ar)`), data attributes, CSS variables, comment banners and
code style.

## Step 2: what to build

### A. Put the course inside the website

- Create `medical-analytics-training/pypath/` and copy **only** the course files for each
  finished day: `dayNN/index.html`, `dayNN/style.css`, `dayNN/script.js`, `dayNN/dayNN.pdf`
  (currently Day 1 and Day 2; check `PROCESS.md` for the current status).
- Create `medical-analytics-training/pypath/index.html`, the **PyPath landing page ("the
  path")**. It's readable, hand-written HTML in PyPath's own style (reuse `day01/style.css`
  or add a small `pypath/home.css`). It contains a title and short intro, the 30 days
  grouped by phase (Python Basics, Data Science, Machine Learning, Deep Learning, NLP)
  taken from the plan in the knowledge file, a link and a PDF link for each finished day,
  "coming soon" for the rest, and a clear "← Back to Medical Analytics Training" link
  to `../index.html`. It must work from `file://` and from the dev server.
- **Don't change how the day pages work.** In particular, don't add a 30-day progress header
  to day pages (the PyPath author doesn't want one). If you think the day pages need a way
  back to the landing page, **ask me first**.

### B. The navbar button (desktop / wide screens)

- In the top navigation bar (`.main-nav`, built by `Shell.links()` / `renderHeader()` in
  `js/shared.js`), add **PyPath** right after the lecture links ("Lecture 1 · Lecture 2 ·
  PyPath"). Style it as a **button** (a pill or outlined button that fits the header,
  using the existing CSS variables), not a plain text link. Clicking it opens
  `pypath/index.html`.
- It must appear on every page that uses the shell: home, both lectures and the agent
  report.
- Add the label to **both** I18N dictionaries. "PyPath" can stay the same in Arabic, but
  give it a translated `title`/`aria-label`, e.g. "PyPath — 30 days of Python" /
  "PyPath — ٣٠ يومًا من بايثون". Check the RTL (Arabic) layout too.

### C. Small screens (when the navbar collapses)

- At 980 px and below the site hides `.main-nav` and shows the menu button; the drawer
  then holds the navigation and, at the bottom, the **language and theme options**
  (`.drawer-tools`).
- There, add a full-width **PyPath** button placed **directly above the language and theme
  options** (above `.drawer-tools`, below the drawer's nav/sections). It opens
  `pypath/index.html`. Make it look like a button, keep it reachable by keyboard and
  inside the drawer's focus trap, and keep it working when the language switches (the
  drawer is re-rendered).

### D. Keep the project consistent

- Add `pypath/**` (only the course files and the landing page) to the website zip in
  `tools/make_share_package.py`, and mention PyPath in its `OPEN-ME` text.
- Update `README.md`: features, project structure and navigation. Note that PyPath pages
  need internet the first time (they download Python), unlike the rest of the site.
- Optionally add PyPath to the footer's "Learn" list, following how the lectures are listed.

## Step 3: test

- Serve the site the way `.claude/launch.json` does
  (`python -m http.server 8765 --directory medical-analytics-training`) and also open it
  from `file://`.
- Check at widths of about 1280, 1000, 900, 700 and 375 px, in English and Arabic (RTL),
  in light and dark themes. The button must be visible and correct in each place: navbar
  on wide screens; inside the menu, above the language and theme options, on narrow
  screens.
- Click through: home → PyPath → landing page → Day 1 → back; lectures → PyPath.
- Run the PyPath day tests from the copied location if possible (`node
  <PYPATH_PATH>/tools/test-day.mjs`, or copy the tool next to the copied days). Every day
  must still print `ALL PASSED`.
- Make sure the site's existing features still work: language and theme switching, the
  drawer, lecture navigation, and the Data Agent button.

## Rules

- Read first, then change. Make small, focused edits in the existing style. Don't
  reformat or rewrite files you don't need to change.
- Never copy the PyPath author's personal files (`.venv`, `train.csv`, `.py` scripts,
  nested projects).
- Don't commit, push or deploy unless I ask. When done, show me a summary of every
  changed or added file, what you tested, and anything you weren't sure about.
