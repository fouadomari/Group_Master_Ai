# PyPath — complete project knowledge

Everything learned while building **PyPath**, a 30-day course that teaches classmates who
have never coded: Python → data science → machine learning → deep learning → NLP.
Read this fully before touching PyPath files. (Written 2026-10-20.)

---

## 1. What PyPath is

- **Audience:** complete beginners (university classmates), English-language lessons.
- **Length:** 30 days, one lesson per day, about 60 minutes each.
- **Form:** each day is a **folder** with a readable web page where Python really runs
  in the browser, plus a printable PDF.
- **Built one day at a time.** Each day is agreed on, written, tested and printed before
  the next one starts.
- **Status (2026-10-20):** Day 1 and Day 2 are finished, tested and printed. Days 3–30 are
  not started.

---

## 2. What the author wants, and why

These rules come straight from the author. Follow them.

1. **Readable files only.** Every file must make sense when opened in a text editor:
   hand-written, indented HTML; commented CSS; short commented JavaScript.
   No React or other framework, no bundler (Vite/webpack), no minifying, no build step.
   *Why:* a first version used React + Vite. Its output was one 800 KB minified line per
   page, the author called it "a total disaster", and it was deleted.
2. **One folder per day**: `dayNN/` with `index.html`, `style.css`, `script.js` and
   `dayNN.pdf`.
3. **No 30-day progress header or bar** on the day pages (asked for explicitly).
4. **No server, login or database.** Pages open by double-clicking (`file://`).
   *Why:* an Express + SQLite + login version was built and then dropped. The course is
   shared as files with classmates.
5. **Made-up data only**, clearly labelled as made up. Nothing is downloaded.
6. **Plain, friendly English** for people who have never coded. Explain every new word.

---

## 3. Folder layout

```
pypath/
  PROCESS.md            the working plan + status (keep it updated)
  day01/
    index.html          the lesson (all content lives here)
    style.css           shared look (identical in every day folder)
    script.js           shared behaviour (identical in every day folder)
    day01.pdf           printable version, made by tools/make-pdf.mjs
  day02/ …
  tools/
    test-day.mjs        automated browser test of one day
    make-pdf.mjs        builds dayNN/dayNN.pdf
  agent-kit/            this knowledge file, the skill, the agent prompt
```

- `style.css` and `script.js` are **the same file in every day folder**. If you improve
  one, copy it to every day and re-test them all.
- Course files are only `index.html`, `style.css`, `script.js`, `dayNN.pdf`. The author's
  personal working files may sit in the same folders (`.venv`, `.py` scripts, big CSVs,
  other projects). They are **not** course files: never ship or edit them.

---

## 4. Anatomy of a day page (`index.html`)

### 4.1 Head and body

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="color-scheme" content="light dark">
  <title>Day 2: Variables and data types · PyPath</title>
  <link rel="stylesheet" href="style.css">
  <!-- Python for the browser (Pyodide). Downloaded the first time, then cached. -->
  <script src="https://cdn.jsdelivr.net/pyodide/v314.0.7/full/pyodide.js"></script>
</head>
<body data-day="day02">          <!-- used as the localStorage key: "pypath-day02" -->
<main> … lesson … </main>
<div id="python-status" role="status"></div>
<script src="script.js"></script>
</body>
</html>
```

Each section is introduced by a comment banner:
`<!-- ===== TODAY'S GOAL ===== -->`.

### 4.2 Lesson structure (every day, in this order)

1. Header: `<p class="muted small">Python Basics · Day N of 30 · about 60 minutes</p>`,
   `<h1>`, and the "↺ Forget variables" button (`id="reset-variables"`).
2. `🎯 Today's goal`: 3–5 bullet points.
3. `🤔 Why this matters`: a plain analogy plus the real data/AI use.
4. Teaching sections with emoji `h2`s, short paragraphs, tables, `.note` tip boxes, and
   **code boxes** that build on each other.
5. 1–2 **errors on purpose** where useful (reading errors is a skill).
6. `⚠️ Common mistakes`, then `✅ Recap`.
7. `🏋️ Exercises`: a score bar and 4–6 exercises, easy → harder, the last one a "Challenge".
8. `<section id="finished" class="finished" hidden>`: the "🏆 Day N complete!" message.
9. `🔜 Tomorrow`: a preview of the next day's topic.
10. `<footer class="screen-only">`: a storage note and the "Erase my answers" button
    (`id="erase-progress"`).

### 4.3 A lesson code box

```html
<div class="cell">                     <!-- add class "error-demo" if it must fail -->
  <textarea>
print("Hello, world!")</textarea>      <!-- code starts on the line after <textarea>;
                                            </textarea> directly after the last character -->
  <div class="buttons">
    <button class="run">▶ Run</button>
    <button class="reset quiet" hidden>↺ Reset</button>
    <span class="shortcut">Shift + Enter</span>
  </div>
  <div class="output"></div>
</div>
```

- All lesson boxes on one page **share variables** (one namespace, like a notebook), so
  later boxes may use earlier variables. Tell learners to run boxes top to bottom.
- `class="cell error-demo"` adds a yellow "mistake on purpose" label (pure CSS) and means
  the box **must** raise an error.
- If the last line is an expression, its value is shown (like Jupyter). pandas tables
  show as HTML tables, and charts show as images.
- Escape `<` and `&` inside a `<textarea>` (`&lt;`, `&amp;`).

### 4.4 An exercise

```html
<section class="exercise" id="game-score">        <!-- id: kebab-case, unique on the page -->
  <h3>2. Game score</h3>
  <p>Task… name the variable the learner must create, e.g. <code>score</code>.</p>
  <textarea>
score = 10

# Add 5 points
</textarea>                                        <!-- the starting code -->
  <div class="buttons">
    <button class="check">✓ Check my answer</button>
    <button class="start-over quiet">↺ Start over</button>
    <button class="hint quiet">💡 Hint</button>
    <button class="show-solution quiet" hidden>👀 Show solution</button>
    <span class="tries-note muted small" hidden></span>
  </div>
  <ol class="hints" hidden>
    <li hidden>First hint.</li>
    <li hidden>Last hint can nearly give it away.</li>
  </ol>
  <div class="output"></div>
  <div class="result" hidden></div>
  <div class="solution-box" hidden>
    <strong>One possible solution</strong>
    <pre></pre>
    <button class="copy-solution quiet">Copy into my box</button>
  </div>
<script type="text/python" class="tests">
assert "score" in globals(), "Keep the variable called score."
assert score == 30, f"The final score should be 30, but it is {score}."
</script>
<script type="text/python" class="solution">
score = 10
score += 5
score *= 2
</script>
</section>
```

- The `<script type="text/python">` blocks are **never executed by the browser**. script.js
  reads their text. Keep their Python **flush-left** (no HTML indentation), or it becomes
  an IndentationError.
- Update the score text `0 / N done` to the real number of exercises.

### 4.5 Rules for tests

- Tests are Python `assert` lines with **friendly messages** (the message is what the
  learner sees).
- They run **after** the learner's code, in a **fresh namespace** (nothing from the
  lesson boxes). So the starter must contain any setup the task needs (imports, data).
- Available to tests: every variable the learner made (`globals()`), `__output__` (all
  printed text), `__lines__` (printed lines, trimmed, blanks removed) and `__code__` (the
  learner's code as text).
- Prefer "store the answer in a variable called X" and test X. Guard first:
  `assert "x" in globals(), "Create a variable called x."`. Use tolerances for floats:
  `abs(x - 19.5) < 0.01`.
- Stop hard-coded answers with `__code__` checks (e.g. `"+=" in __code__`, `"float(" in
  __code__`). Where possible compute the expected value from the learner's own input
  variables, so the answer must work if the inputs change.
- **The starter code must FAIL and the solution must PASS.** tools/test-day.mjs checks
  both for every exercise.
- Floating point: `(17.2 + 21.9 + 19.4) / 3` isn't exactly 19.5, so ask for formatted
  output (`{x:.1f}`) or use tolerances.
- Charts are closed before tests run, so tests can't inspect plots. Test the data
  variables and/or `"plt.bar" in __code__`.

### 4.6 Screen vs paper

- `class="screen-only"`: hidden in print/PDF (e.g. "click ▶ Run", the footer).
- `class="print-only"`: shown only in print/PDF (e.g. "open this day's index.html to run
  the code yourself", "solutions are in the answer key at the end").
- Every day needs: a screen-only exercise intro, a print-only exercise intro, and
  `<footer class="screen-only">`.

---

## 5. How `script.js` works

Numbered, commented sections:

1. **`PYTHON_HELPER`**: Python code in a `String.raw` template (so `\n` stays literal;
   never put backticks or `${` in it). It provides:
   - `run_lesson_code(code, emit)`: runs code in the shared lesson namespace.
   - `check_exercise(code, tests, emit)`: fresh namespace → run the answer → run the
     tests → `{passed}` or `{passed:false, message}` or `{passed:false, error}`.
   - `reset_lesson()`: clears the lesson namespace (the "Forget variables" button).
   - `preimport(code)`: parses imports with `ast` and imports them **before** the time
     limit starts (pandas/sklearn can take 10+ s the first time).
   - **Time limit:** a `sys.settrace` tracer stops the learner's code after 20 s with
     `TimeLimitExceeded`. Only frames whose file name is `<cell>` are traced, so
     libraries run at full speed.
   - Error messages are trimmed to the learner's own lines (`linecache` is filled, so
     the code line is shown with a caret).
   - `input()` raises a friendly message (it can't work in the browser).
   - Matplotlib uses the `AGG` backend. After each run every figure is sent as a base64
     PNG and closed.
   - Output kinds sent to the page: `text`, `warning` (stderr), `html` (`_repr_html_`,
     e.g. DataFrames), `image`.
2. **Loading Python**: `loadPyodide({indexURL: CDN})` starts at page load. The status
   pill `#python-status` shows loading, ready, running or error.
3. **One job at a time**: a promise queue. `prepare(code)` calls
   `pyodide.loadPackagesFromImports`, then `preimport`. `waitForScreen()` lets the page
   repaint ("Running…") before Python blocks the main thread.
4. **Output**: `makePrinter(outputArea)` joins text chunks and caps output at 200 000
   characters. `showError()` shows the error type, a plain-language hint (from
   `ERROR_HINTS`) and the trimmed traceback.
5. **Editors**: plain `<textarea>`s that grow to fit. Tab inserts 4 spaces;
   Shift/Ctrl+Enter runs the box (or checks the exercise). No syntax colours: an editor
   library would make the files unreadable.
6. **Progress**: `localStorage["pypath-dayNN"] = { "exercise-id": {passed, tries, code} }`.
   Every access is wrapped in try/catch (private windows can block storage).
7. **Exercises**: Check, Start over, hints one at a time, "Show solution" after 3 failed
   tries (or once passed), "Copy into my box", the score bar, and the `#finished` message.

---

## 6. Technical lessons learned (hard-won; don't relearn them)

- **`file://` + Chrome blocks module web workers**, both blob and data URLs. This was
  tested. Pyodide 314.x needs a *module* worker ("Classic web workers are not
  supported"), so Python **must run on the main thread**. Hence the time limit and the
  "page freezes while code runs" behaviour.
- A classic `<script src="…pyodide.js">` from jsDelivr **does** work on `file://`.
- Pyodide version **314.0.7** (Python 3.14). It needs internet the first time; the
  browser caches it after that. The full offline bundle is about 340 MB, too big to ship.
- Available: numpy 2.4, pandas 3.0, matplotlib 3.10, scikit-learn 1.8, scipy 1.18,
  nltk 3.9.
  - pandas 3: copy-on-write and a string dtype by default. Chained assignment
    `df["a"][0] = 1` does nothing; use `.loc`.
  - nltk: `PorterStemmer` and `wordpunct_tokenize` work. Anything needing nltk data
    (`word_tokenize`, the stopwords corpus, WordNet) does **not** (no downloads).
  - sklearn built-in datasets work offline: `load_iris`, `load_digits`, `load_wine`,
    `load_breast_cancer`, `load_diabetes`. `fetch_*` datasets do not.
- **Not available:** seaborn, torch, tensorflow, transformers, internet data. Deep
  learning days use NumPy (by hand) and sklearn `MLPClassifier`. PyTorch/Keras are shown
  as read-only code (not runnable).
- Timings seen in the browser: the first box that imports pandas/sklearn takes 10–19 s
  (download + import, outside the time limit); later boxes take under 3 s. `MLPClassifier`
  on `load_digits` (64 hidden units, about 200 iterations) takes about 4 s.
- An editable `<textarea>` in print gets clipped. The PDF tool swaps each textarea for
  `<pre class="code">` before printing.
- A naive "insert before `</head>`" breaks when bundled JS contains the text `</head>`.
  Use the last occurrence (this only mattered for the old bundled version).
- `pkill -f <pattern>` inside a shell command whose own text contains the pattern kills
  that shell. Use the `[c]hrome`-style bracket trick.

---

## 7. Tools

Both need Node.js 22+, Google Chrome and internet. Run them from the `pypath/` folder.

| Command | What it does |
|---|---|
| `node tools/test-day.mjs dayNN` | Hidden Chrome opens the page from disk and checks: Python loads; every box runs (error-demo boxes must error); every exercise **rejects the starter and accepts the solution**; score and "complete" message; solution unlocks after exactly 3 wrong tries; hints; typed answer survives reload; `while True: pass` is stopped; no sideways scroll at 375 px. Must end with `ALL PASSED`. |
| `node tools/make-pdf.mjs dayNN [dayMM …]` | Runs every example so outputs are filled in, resets exercises to their starters, swaps textareas for `<pre class="code">`, appends an "🔑 Answer key" page, and prints A4 in light colours with "page X of Y" footers to `dayNN/dayNN.pdf`. The look comes from `@media print` in style.css (buttons hidden, hints shown, a dashed writing box under each exercise, no page breaks inside boxes). |

After making a PDF, **look at it**: render the pages (`pdftoppm -r 50 -png …`) and check for
clipped code or leftover screen-only text.

---

## 8. Workflow for each new day

1. Agree on the day's content (topics, examples, exercises) with the author.
2. `mkdir dayNN` and copy `style.css` and `script.js` from the latest day **unchanged**.
3. Write `dayNN/index.html` following §4. Use `<body data-day="dayNN">`, the right title,
   "Day N of 30" and the phase name.
4. `node tools/test-day.mjs dayNN` → must print `ALL PASSED` with no page errors.
5. `node tools/make-pdf.mjs dayNN` → look through the PDF.
6. Update the Status section of `PROCESS.md`.

Content guidance:
- 8–15 code boxes, 4–6 exercises; every cell and exercise fast (aim < 3 s).
- Only use ideas taught on earlier days, or explain them on the spot.
- Use data-flavoured examples (temperatures, prices, scores, patients…), because the
  course leads to data science.
- Seed randomness (`np.random.seed`, `random_state=42`) so outputs are reproducible.
- When data is used: made up, small, created in the lesson code or written into the page.

---

## 9. The 30-day plan

| Day | Topic | Phase |
|---|---|---|
| 1 | Hello, Python! Python as a calculator | Python Basics |
| 2 | Variables and data types | Python Basics |
| 3 | Lists and dictionaries | Python Basics |
| 4 | Making decisions with if / else | Python Basics |
| 5 | Repeating work with loops | Python Basics |
| 6 | Writing your own functions | Python Basics |
| 7 | Files, modules and handling errors | Python Basics |
| 8 | Mini-project: expense tracker | Python Basics |
| 9 | NumPy: fast math on arrays | Data Science |
| 10 | Pandas I: loading and inspecting data | Data Science |
| 11 | Pandas II: filtering, sorting and grouping | Data Science |
| 12 | Cleaning messy data | Data Science |
| 13 | Charts with Matplotlib | Data Science |
| 14 | Exploratory data analysis (EDA) | Data Science |
| 15 | Mini-project: ship passengers EDA | Data Science |
| 16 | What is machine learning? Train/test split | Machine Learning |
| 17 | Linear regression: predicting numbers | Machine Learning |
| 18 | Classification: logistic regression and KNN | Machine Learning |
| 19 | Decision trees and random forests | Machine Learning |
| 20 | Evaluating models | Machine Learning |
| 21 | Clustering with K-means | Machine Learning |
| 22 | Mini-project: survival predictor | Machine Learning |
| 23 | A neuron from scratch | Deep Learning |
| 24 | Gradient descent and a 2-layer network | Deep Learning |
| 25 | Recognising handwritten digits | Deep Learning |
| 26 | Overfitting, regularisation and real-world frameworks | Deep Learning |
| 27 | Text basics: cleaning and tokenising | NLP |
| 28 | Bag-of-words and TF-IDF | NLP |
| 29 | Sentiment classifier | NLP |
| 30 | Capstone: review analyzer + what next | NLP |

### What Day 1 and Day 2 contain

- **Day 1, Hello, Python!** (10 boxes, 5 exercises): `print`, strings vs numbers, the
  operators table (`+ - * / // % **`), the last-expression display, order of operations,
  comments, `"5" + "5"`, concatenation, and errors on purpose (SyntaxError, TypeError).
  Exercises: hello, fix-bug, seconds, shopping, pizza.
- **Day 2, Variables and data types** (13 boxes, 5 exercises): assignment (`=` means
  "store"), `+= -= *= /=`, snake_case naming (NameError demo), `int/float/str/bool` and
  `type()`, booleans from comparisons, `int()/float()/str()/round()` (ValueError demo),
  f-strings with `:.1f`/`:.2f`, and `.strip/.lower/.upper/.title/.replace/len`. Exercises:
  profile, game-score, convert, average-temp, report (challenge).

---

## 10. History (so you don't repeat it)

1. **v1:** Node/Express + React + SQLite with logins. Hosting it publicly was discussed
   (the domain's DNS is at Hostinger, not Cloudflare) and then dropped.
2. **v2:** a single self-contained HTML file. Then one HTML file per day. Then 30 folders
   (HTML + CSS), all built by Vite. All 30 days were written by sub-agents and fully
   tested, but the built files were minified and unreadable.
3. **v3 (current):** everything deleted (moved to the Trash). Rebuilt by hand, one day at
   a time, as readable HTML/CSS/JS + PDF.
