---
name: pypath-course
description: Build, edit, test, print or embed PyPath — a 30-day beginner course (Python → data science → ML → deep learning → NLP) where each day is a readable dayNN/ folder (index.html + style.css + script.js + dayNN.pdf) with Python running in the browser via Pyodide. Use when asked to make or change a PyPath day, make its PDF, test it, or add PyPath to another website (e.g. a navbar link).
---

# PyPath course

PyPath is a 30-day course for complete beginners. Each day is a hand-written folder
`dayNN/` that opens by double-clicking `index.html`. Python runs in the page (Pyodide from
the jsDelivr CDN), exercises check themselves, and progress is saved in `localStorage`.

**First, read `references/PYPATH-KNOWLEDGE.md` fully.** It holds the author's rules, the
exact HTML anatomy, how `script.js` works, the technical lessons learned, the 30-day plan
and the history. Don't skip it: several "obvious" approaches (React/Vite, web workers,
servers) were tried and rejected.

## Non-negotiable rules

- **Readable files only:** indented HTML, commented CSS/JS. No frameworks, bundlers,
  minifying or build step.
- **One folder per day:** `index.html`, `style.css`, `script.js`, `dayNN.pdf`. `style.css`
  and `script.js` are identical in every day; if you change one, copy it to all days and
  re-test them all.
- **No 30-day progress header** on day pages. No server, login or database.
- **Made-up data only,** labelled as made up. Plain, friendly English.
- **Python on the main thread** (Chrome blocks module workers on `file://`). Keep the 20 s
  `settrace` time limit and the import-before-timer step.
- Folders may also contain the author's unrelated personal files (`.venv`, `.py`, big
  CSVs, other projects). Never edit, ship or copy them.

## Files in this skill

| Path | Use |
|---|---|
| `references/PYPATH-KNOWLEDGE.md` | All project knowledge. Read first. |
| `assets/style.css`, `assets/script.js` | The current shared files (copy into a new day unchanged). |
| `assets/example-day.html` | Day 2, a complete example page to copy patterns from. |
| `scripts/test-day.mjs` | Browser test. Copy to `<pypath>/tools/` and run `node tools/test-day.mjs dayNN`. |
| `scripts/make-pdf.mjs` | PDF maker. Copy to `<pypath>/tools/` and run `node tools/make-pdf.mjs dayNN`. |

Both scripts find the course as the parent of their own folder, so they must live in
`<pypath>/tools/`. They need Node.js 22+, Google Chrome and internet.

## Task: make a new day

1. Read `PROCESS.md` (status) and the previous day's `index.html` in the real `pypath/`
   folder. If they differ from this skill's copies, **the project folder wins**.
2. Agree on the topics, examples and exercises with the user (see the 30-day plan).
3. `mkdir dayNN`. Copy `style.css` and `script.js` from the latest day.
4. Write `index.html` following the knowledge file §4: header → 🎯 → 🤔 → teaching
   sections with code boxes → 1–2 `error-demo` boxes → ⚠️ → ✅ → 🏋️ (4–6 exercises,
   flush-left Python in the `tests`/`solution` script blocks) → `#finished` → 🔜 →
   `<footer class="screen-only">`. Set `<body data-day="dayNN">`, the title, "Day N of 30",
   the phase and the `0 / N done` text. Add the screen-only and print-only exercise intros.
5. `node tools/test-day.mjs dayNN` → it must print `ALL PASSED` with no page errors. Fix
   and repeat.
6. `node tools/make-pdf.mjs dayNN`, then look at the pages (e.g. `pdftoppm -r 50 -png`)
   for clipped code or screen-only text.
7. Update the Status section of `PROCESS.md`.

## Task: change an existing day

Read the whole page first. Keep its structure and comment banners. Re-run the test and
re-make the PDF afterwards.

## Task: embed PyPath in another website

1. **Read the host project first:** its README, every file of its page shell (header/nav,
   language and theme handling, CSS breakpoints), its `.claude/` folder (e.g.
   `launch.json` shows how it is served) and its share/build scripts. Copy its patterns
   (naming, i18n keys, data attributes, comment style, CSS variables).
2. Copy only the course files (`dayNN/index.html`, `style.css`, `script.js`, `dayNN.pdf`)
   into a `pypath/` folder inside the host site. Add a `pypath/index.html` landing page that
   lists all 30 days (links for finished days, "coming soon" for the rest) and links back
   to the host site.
3. Add the link or button the user asked for, using the host's own components, in **every**
   navigation place the host has (desktop nav and mobile drawer). Translate its label if
   the host is multilingual.
4. Test: every width breakpoint, every language (including RTL), both themes, from
   `file://` and from the host's dev server. Update the host's README and its share/zip
   script so `pypath/` is included.
5. Don't commit or push unless the user asks.
