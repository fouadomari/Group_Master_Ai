/*
 * Makes a printable PDF of a day's lesson.
 *
 *   node tools/make-pdf.mjs day01            → day01/day01.pdf
 *   node tools/make-pdf.mjs day01 day02      → one PDF per day
 *
 * How it works: it opens dayNN/index.html in Google Chrome (hidden, "headless"),
 * waits for Python to load, runs every example box so its output is filled in,
 * adds an answer key with the exercise solutions at the end, and saves it as a PDF.
 * The print styles at the bottom of style.css decide what the PDF looks like.
 *
 * Needs: Node.js 22+ and Google Chrome. Needs internet (Python is downloaded).
 */

import { spawn } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

const COURSE_DIR = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const CHROME = process.env.CHROME || "google-chrome";
const PORT = 9334;

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));


/* ---------- Talking to Chrome (DevTools protocol) ---------- */

async function startChrome() {
  const profile = fs.mkdtempSync(path.join(os.tmpdir(), "pypath-pdf-"));
  const chrome = spawn(CHROME, [
    "--headless=new",
    `--remote-debugging-port=${PORT}`,
    `--user-data-dir=${profile}`,
    "about:blank",
  ], { stdio: "ignore" });

  // Wait until Chrome is listening, then connect to its page.
  let pages = [];
  for (let i = 0; i < 60 && !pages.length; i++) {
    await sleep(250);
    try {
      pages = (await (await fetch(`http://127.0.0.1:${PORT}/json`)).json()).filter((t) => t.type === "page");
    } catch {
      /* not ready yet */
    }
  }
  if (!pages.length) throw new Error("Could not start Google Chrome.");

  const socket = new WebSocket(pages[0].webSocketDebuggerUrl);
  await new Promise((resolve) => socket.addEventListener("open", resolve));

  let nextId = 1;
  const waiting = new Map();
  socket.addEventListener("message", (event) => {
    const message = JSON.parse(event.data);
    if (message.id && waiting.has(message.id)) {
      waiting.get(message.id)(message);
      waiting.delete(message.id);
    }
  });

  // send("Page.navigate", {...}) → the reply from Chrome
  const send = (method, params = {}) =>
    new Promise((resolve) => {
      const id = nextId++;
      waiting.set(id, resolve);
      socket.send(JSON.stringify({ id, method, params }));
    });

  // run("some JavaScript") → its result, evaluated inside the page
  const run = async (expression) => {
    const reply = await send("Runtime.evaluate", { expression, awaitPromise: true, returnByValue: true });
    if (reply.result?.exceptionDetails) throw new Error(reply.result.exceptionDetails.text);
    return reply.result?.result?.value;
  };

  // Close Chrome, wait until it has really exited, then delete its temporary profile.
  const stop = async () => {
    socket.close();
    const exited = new Promise((resolve) => chrome.once("exit", resolve));
    chrome.kill();
    await exited;
    fs.rmSync(profile, { recursive: true, force: true, maxRetries: 5, retryDelay: 200 });
  };

  return { send, run, stop };
}

async function waitUntil(run, expression, seconds) {
  for (let waited = 0; waited < seconds * 1000; waited += 250) {
    if (await run(expression)) return;
    await sleep(250);
  }
  throw new Error(`Timed out waiting for: ${expression}`);
}


/* ---------- Making one PDF ---------- */

async function makePdf(browser, day) {
  const page = path.join(COURSE_DIR, day, "index.html");
  if (!fs.existsSync(page)) throw new Error(`${page} does not exist.`);
  const { send, run } = browser;

  await send("Page.enable");
  await send("Page.navigate", { url: "file://" + page });
  await sleep(1000);

  console.log(`${day}: waiting for Python…`);
  await waitUntil(run, `document.getElementById("python-status").dataset.state === "ready"`, 180);

  // Run every example box, one after another, so the outputs appear.
  const boxes = await run(`document.querySelectorAll(".cell").length`);
  for (let i = 0; i < boxes; i++) {
    const box = `document.querySelectorAll(".cell")[${i}]`;
    await run(`${box}.querySelector(".run").click()`);
    await sleep(100);
    await waitUntil(run, `!${box}.querySelector(".run").disabled`, 60);
  }
  console.log(`${day}: ran ${boxes} example boxes`);

  // Prepare the page for printing:
  //  - put each exercise back to its starting code and clear any output
  //  - add an answer key with every solution at the end
  await run(`(() => {
    document.querySelectorAll(".exercise").forEach((exercise) => {
      const box = exercise.querySelector("textarea");
      box.value = box.defaultValue;
      exercise.querySelector(".output").innerHTML = "";
    });

    const key = document.createElement("section");
    key.className = "answer-key";
    key.innerHTML = "<h2>🔑 Answer key</h2><p class='muted'>Try the exercises yourself first! There is often more than one correct answer.</p>";
    document.querySelectorAll(".exercise").forEach((exercise) => {
      const title = document.createElement("h3");
      title.textContent = exercise.querySelector("h3").textContent;
      const code = document.createElement("pre");
      code.textContent = exercise.querySelector(".solution").textContent.trim();
      key.append(title, code);
    });
    document.querySelector("footer").before(key);

    // Paper can't scroll, so swap each editable code box for plain text that
    // wraps long lines and grows to fit (styled by "pre.code" in style.css).
    document.querySelectorAll("textarea").forEach((box) => {
      const code = document.createElement("pre");
      code.className = "code";
      code.textContent = box.value;
      box.replaceWith(code);
    });
  })()`);

  // Print in light colours, on A4 paper, with page numbers at the bottom.
  await send("Emulation.setEmulatedMedia", { media: "print", features: [{ name: "prefers-color-scheme", value: "light" }] });
  const title = await run("document.title");
  const pdf = await send("Page.printToPDF", {
    paperWidth: 8.27,
    paperHeight: 11.69,
    marginTop: 0.6,
    marginBottom: 0.7,
    marginLeft: 0.6,
    marginRight: 0.6,
    printBackground: true,
    displayHeaderFooter: true,
    headerTemplate: "<span></span>",
    footerTemplate: `<div style="font-size:8px;width:100%;text-align:center;color:#777">${title} · page <span class="pageNumber"></span> of <span class="totalPages"></span></div>`,
  });
  if (!pdf.result?.data) throw new Error("Chrome could not make the PDF: " + JSON.stringify(pdf.error));

  const output = path.join(COURSE_DIR, day, `${day}.pdf`);
  fs.writeFileSync(output, Buffer.from(pdf.result.data, "base64"));
  console.log(`${day}: saved ${path.relative(COURSE_DIR, output)}`);
}


/* ---------- Main ---------- */

const days = process.argv.slice(2);
if (!days.length) {
  console.log("Usage: node tools/make-pdf.mjs day01 [day02 ...]");
  process.exit(1);
}

const browser = await startChrome();
try {
  for (const day of days) await makePdf(browser, day);
} finally {
  await browser.stop();
}
