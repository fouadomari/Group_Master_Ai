/*
 * Tests a day's page the way a learner would use it, in a hidden Chrome window.
 *
 *   node tools/test-day.mjs day01
 *
 * Checks: Python loads; every example box runs (and the "mistake on purpose" boxes
 * show an error); every exercise rejects its starting code and accepts its solution;
 * hints and "Show solution" work; typed answers survive a reload; endless loops are
 * stopped; the page fits a phone screen. Prints ✓ / ✗ for each check.
 *
 * Needs: Node.js 22+, Google Chrome and internet (Python is downloaded).
 */

import { spawn } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

const COURSE_DIR = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const day = process.argv[2];
if (!day) {
  console.log("Usage: node tools/test-day.mjs day01");
  process.exit(1);
}
const url = "file://" + path.join(COURSE_DIR, day, "index.html");
const PORT = 9335;
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));


/* ---------- Start Chrome and connect ---------- */

const profile = fs.mkdtempSync(path.join(os.tmpdir(), "pypath-test-"));
const chrome = spawn(process.env.CHROME || "google-chrome",
  ["--headless=new", `--remote-debugging-port=${PORT}`, `--user-data-dir=${profile}`, "--window-size=1000,900", "about:blank"],
  { stdio: "ignore" });

let pages = [];
for (let i = 0; i < 60 && !pages.length; i++) {
  await sleep(250);
  try {
    pages = (await (await fetch(`http://127.0.0.1:${PORT}/json`)).json()).filter((t) => t.type === "page");
  } catch {
    /* not ready yet */
  }
}
const socket = new WebSocket(pages[0].webSocketDebuggerUrl);
await new Promise((resolve) => socket.addEventListener("open", resolve));

let nextId = 1;
const waiting = new Map();
const pageErrors = [];
socket.addEventListener("message", (event) => {
  const m = JSON.parse(event.data);
  if (m.id && waiting.has(m.id)) waiting.get(m.id)(m);
  if (m.method === "Runtime.exceptionThrown") pageErrors.push(m.params.exceptionDetails.exception?.description || m.params.exceptionDetails.text);
});
const send = (method, params = {}) => new Promise((resolve) => {
  const id = nextId++;
  waiting.set(id, resolve);
  socket.send(JSON.stringify({ id, method, params }));
});
const js = async (expression) =>
  (await send("Runtime.evaluate", { expression, awaitPromise: true, returnByValue: true })).result?.result?.value;
const waitFor = async (expression, ms = 90000) => {
  for (let t = 0; t < ms; t += 250) {
    if (await js(expression)) return true;
    await sleep(250);
  }
  return false;
};

let failures = 0;
const check = (passed, message) => {
  console.log(`${passed ? "✓" : "✗"} ${message}`);
  if (!passed) failures++;
};

const pythonReady = `document.getElementById("python-status").dataset.state === "ready"`;
await send("Runtime.enable");
await send("Page.enable");
await send("Page.navigate", { url });
await sleep(1000);
check(await waitFor(pythonReady, 180000), "Python loads");


/* ---------- Example boxes ---------- */

const boxCount = await js(`document.querySelectorAll(".cell").length`);
for (let i = 0; i < boxCount; i++) {
  const box = `document.querySelectorAll(".cell")[${i}]`;
  await js(`${box}.querySelector(".run").click()`);
  await sleep(50);
  await waitFor(`!${box}.querySelector(".run").disabled`);
  const r = await js(`({ onPurpose: ${box}.classList.contains("error-demo"), error: !!${box}.querySelector(".error"), output: ${box}.querySelector(".output").innerText })`);
  check(r.onPurpose === r.error, `box ${i + 1}${r.onPurpose ? " (mistake on purpose)" : ""}: ${JSON.stringify(r.output.slice(0, 70))}`);
}


/* ---------- Exercises: starting code fails, solution passes ---------- */

const exerciseIds = await js(`[...document.querySelectorAll(".exercise")].map((e) => e.id)`);
for (const id of exerciseIds) {
  const ex = `document.getElementById(${JSON.stringify(id)})`;
  const pressCheck = async () => {
    await js(`${ex}.querySelector(".check").click()`);
    await sleep(50);
    await waitFor(`!${ex}.querySelector(".check").disabled`);
    return js(`({ good: ${ex}.querySelector(".result").classList.contains("good") && !${ex}.querySelector(".result").hidden,
                  text: ${ex}.querySelector(".result").innerText,
                  error: ${ex}.querySelector(".error")?.innerText.split("\\n")[0] || null })`);
  };
  const starter = await pressCheck();
  check(!starter.good, `${id}: starting code is not accepted (${starter.error || starter.text})`);
  await js(`${ex}.querySelector("textarea").value = ${ex}.querySelector(".solution").textContent.trim()`);
  const solution = await pressCheck();
  check(solution.good, `${id}: solution is accepted${solution.good ? "" : ` (${solution.error || solution.text})`}`);
}
const total = exerciseIds.length;
check((await js(`document.getElementById("score-text").innerText`)) === `${total} / ${total} done`, "score shows all exercises done");
check(await js(`!document.getElementById("finished").hidden`), `"Day complete" message is shown`);


/* ---------- Solution unlock, hints, saved answers ---------- */

await js("localStorage.clear()");
await send("Page.reload");
await sleep(1000);
await waitFor(pythonReady);
const first = `document.querySelector(".exercise")`;
for (let tryNumber = 1; tryNumber <= 3; tryNumber++) {
  await js(`${first}.querySelector(".check").click()`);
  await sleep(50);
  await waitFor(`!${first}.querySelector(".check").disabled`);
  const shown = await js(`!${first}.querySelector(".show-solution").hidden`);
  check(shown === (tryNumber >= 3), `wrong try ${tryNumber}: "Show solution" ${shown ? "shown" : "hidden"}`);
}
await js(`${first}.querySelector(".show-solution").click()`);
check(await js(`!${first}.querySelector(".solution-box").hidden &&
                ${first}.querySelector(".solution-box pre").innerText === ${first}.querySelector(".solution").textContent.trim()`),
  "solution appears when clicked");
await js(`${first}.querySelector(".hint").click()`);
check(await js(`!${first}.querySelector(".hints li").hidden`), "first hint appears");

await js(`${first}.querySelector("textarea").value = 'print("remember me")';
          ${first}.querySelector("textarea").dispatchEvent(new Event("input"))`);
await send("Page.reload");
await sleep(1500);
check((await js(`${first}.querySelector("textarea").value`)) === 'print("remember me")', "typed answer survives a reload");


/* ---------- Endless loop, phone width ---------- */

await waitFor(pythonReady);
const box = `document.querySelector(".cell")`;
await js(`${box}.querySelector("textarea").value = "while True:\\n    pass"; ${box}.querySelector(".run").click()`);
await sleep(50);
const started = Date.now();
await waitFor(`!${box}.querySelector(".run").disabled`, 60000);
check((await js(`${box}.querySelector(".error")?.innerText || ""`)).includes("TimeLimitExceeded"),
  `endless loop is stopped (after ${Math.round((Date.now() - started) / 1000)} s)`);

await send("Emulation.setDeviceMetricsOverride", { width: 375, height: 800, deviceScaleFactor: 1, mobile: true });
await sleep(300);
check(!(await js("document.documentElement.scrollWidth > window.innerWidth")), "no sideways scrolling at phone width");


/* ---------- Done ---------- */

console.log(pageErrors.length ? `page errors: ${pageErrors.join(" | ")}` : "no page errors");
console.log(failures ? `${failures} FAILED` : "ALL PASSED");
socket.close();
const exited = new Promise((resolve) => chrome.once("exit", resolve));
chrome.kill();
await exited;
fs.rmSync(profile, { recursive: true, force: true, maxRetries: 5, retryDelay: 200 });
process.exit(failures || pageErrors.length ? 1 : 0);
